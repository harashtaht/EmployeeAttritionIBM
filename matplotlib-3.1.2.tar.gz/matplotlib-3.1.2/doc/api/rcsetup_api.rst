**********************
``matplotlib.rcsetup``
**********************

.. automodule:: matplotlib.rcsetup
   :members:
   :undoc-members:
   :show-inheritance:
