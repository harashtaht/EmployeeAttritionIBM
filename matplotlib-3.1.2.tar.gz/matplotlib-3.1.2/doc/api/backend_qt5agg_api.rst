
:mod:`matplotlib.backends.backend_qt5agg`
=========================================

**NOTE** Not included, to avoid adding a dependency to building the docs.

.. .. automodule:: matplotlib.backends.backend_qt5agg
..    :members:
..    :undoc-members:
..    :show-inheritance:
